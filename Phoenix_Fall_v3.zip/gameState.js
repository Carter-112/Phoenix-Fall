import { PlayerProgress } from 'playerProgress';
export class GameState {
  constructor() {
    // Create player progress instance
    this.playerProgress = new PlayerProgress();
    
    // Try to load saved progress first
    const savedData = this.playerProgress.loadProgress();
    
    // Initialize with defaults and then apply any saved data
    this.reset();
    
    // Apply saved progress if available
    if (savedData) {
      this.playerProgress.applyToGameState(this);
    }
  }
  
  reset() {
    this.xp = 0;
    this.level = 1;
    this.xpToNextLevel = 100;
    this.phoenixGems = 0;
    this.survivalTime = 0;
    this.altitude = 0;
    this.worldComplete = false;
    this.gameOver = false;
    this.currentWorld = 'VolcanicCradle';
    this.worldsCompleted = [];
  }
  
  addXP(amount) {
    this.xp += amount;
    
    // Check level up
    while (this.xp >= this.xpToNextLevel) {
      this.xp -= this.xpToNextLevel;
      this.level++;
      this.phoenixGems++;
      
      // Exponential XP curve
      this.xpToNextLevel = Math.floor(100 * Math.pow(1.5, this.level - 1));
      
      // Trigger level up event - this will be used for health restoration
      if (window.gameInstance && window.gameInstance.phoenix) {
        // Restore 30% of max health on level up
        const healAmount = window.gameInstance.phoenix.maxHealth * 0.3;
        window.gameInstance.phoenix.heal(healAmount);
      }
    }
    
    // Save progress after gaining XP
    this.saveProgress();
    
    // Update the rank display if available
    if (window.rankSystem) {
      // Add some XP to the global rank as well
      window.rankSystem.addXP(Math.round(amount * 0.5));
      
      // Make sure to update the UI if we're on the main menu
      const rankBarElement = document.querySelector('.rank-bar-container');
      if (rankBarElement) {
        // Remove the old rank bar
        rankBarElement.remove();
        
        // Render a new one with updated data
        window.rankSystem.renderRankBar(document.getElementById('renderDiv'));
      }
    }
  }
  
  /**
   * Saves the current game state to persistent storage
   */
  saveProgress() {
    if (this.playerProgress) {
      this.playerProgress.saveProgress(this);
    }
  }
  
  completeWorld() {
    this.worldComplete = true;
    this.worldsCompleted.push(this.currentWorld);
    this.phoenixGems += 5;
    
    // Save progress after completing a world
    this.saveProgress();
  }
  
  // Add total time for level completion
  getTotalLevelTime() {
    return 120; // 2 minutes to complete current level
  }
}