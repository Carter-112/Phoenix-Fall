import React from 'react';
import ReactDOM from 'react-dom/client';
import { WorldSelector } from 'WorldSelector';
export class MainMenu {
  constructor(container) {
    this.container = container;
    this.elements = {};
    
    // Call createMenu immediately
    this.createMenu();
  }
  
  createMenu() {
    // Create menu container
    const menuContainer = document.createElement('div');
    menuContainer.className = 'main-menu';
    menuContainer.style.position = 'absolute';
    menuContainer.style.width = '100%';
    menuContainer.style.height = '100%';
    menuContainer.style.display = 'flex';
    menuContainer.style.flexDirection = 'column';
    menuContainer.style.justifyContent = 'center';
    menuContainer.style.alignItems = 'center';
    menuContainer.style.background = 'linear-gradient(to bottom, #FF5500, #D93d00)';
    menuContainer.style.opacity = '0';
    menuContainer.style.transition = 'opacity 0.5s ease-in';
    menuContainer.style.zIndex = '200'; // Ensure menu is on top
    
    // Force a reflow to ensure transitions work
    setTimeout(() => {
      menuContainer.style.opacity = '1';
    }, 50);
    menuContainer.style.color = 'black';
    menuContainer.style.fontFamily = 'Arial, sans-serif';
    menuContainer.style.zIndex = '200';
    
    // Settings button
    const settingsButton = document.createElement('button');
    settingsButton.className = 'settings-button';
    settingsButton.textContent = '⚙️ Settings';
    settingsButton.className = 'settings-button'; // Add class for CSS targeting
    settingsButton.style.position = 'absolute';
    settingsButton.style.top = '120px'; // Moved up but still below rank bar
    settingsButton.style.right = '10px';
    settingsButton.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    settingsButton.style.color = '#FF5500';
    settingsButton.style.border = '2px solid #FF5500';
    settingsButton.style.borderRadius = '20px';
    settingsButton.style.padding = '8px 15px';
    settingsButton.style.fontSize = '1rem';
    settingsButton.style.cursor = 'pointer';
    settingsButton.style.zIndex = '1001'; // Higher z-index to ensure visibility over all elements
    settingsButton.style.transition = 'all 0.2s ease';
    settingsButton.style.boxShadow = '0 0 10px rgba(255, 85, 0, 0.5)'; // Add glow effect
    settingsButton.style.display = 'block'; // Ensure it's displayed
    settingsButton.style.opacity = '1'; // Ensure it's fully visible
    settingsButton.style.touchAction = 'manipulation'; // Better touch behavior
    
    // Hover effects for settings button
    settingsButton.addEventListener('mouseover', () => {
      settingsButton.style.backgroundColor = 'rgba(40, 40, 40, 0.8)';
      settingsButton.style.transform = 'scale(1.05)';
      settingsButton.style.boxShadow = '0 0 15px rgba(255, 85, 0, 0.8)'; // Enhance glow on hover
    });
    
    settingsButton.addEventListener('mouseout', () => {
      settingsButton.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
      settingsButton.style.transform = 'scale(1)';
      settingsButton.style.boxShadow = '0 0 10px rgba(255, 85, 0, 0.5)'; // Return to normal glow
    });
    
    // Click event for settings button
    settingsButton.addEventListener('click', () => {
      this.showSettingsModal();
    });
    
    
    // Add the CSS animation
    const style = document.createElement('style');
    style.textContent = `
      @keyframes glow {
        from {
          text-shadow: 0 0 10px rgba(0, 0, 0, 0.8);
        }
        to {
          text-shadow: 0 0 20px rgba(0, 0, 0, 1), 0 0 30px rgba(255, 100, 20, 0.8);
        }
      }
      
      @keyframes pulse {
        0% { transform: scale(1); }
        50% { transform: scale(1.05); }
        100% { transform: scale(1); }
      }
      
      @media (max-width: 600px) {
        .main-menu h1 {
          font-size: 2.5rem !important;
        }
        
        .main-menu .content-box {
          width: 90% !important;
          padding: 15px !important;
        }
        
        .main-menu .start-button {
          font-size: 1.2rem !important;
          padding: 10px 20px !important;
        }
        
        .settings-button {
          top: 110px !important; /* Moved up but still below rank bar in mobile view */
          right: 5px !important;
          padding: 6px 12px !important;
          font-size: 0.9rem !important;
          border-radius: 15px !important;
        }
      }
      
      @media (max-width: 400px) {
        .settings-button {
          padding: 5px 10px !important;
          font-size: 0.8rem !important;
        }
      }
    `;
    document.head.appendChild(style);
    
    // Content box with instructions
    const contentBox = document.createElement('div');
    contentBox.className = 'content-box';
    contentBox.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    contentBox.style.padding = '30px';
    contentBox.style.borderRadius = '10px';
    contentBox.style.width = '60%';
    contentBox.style.maxWidth = '600px';
    contentBox.style.marginBottom = '40px';
    contentBox.style.boxShadow = '0 0 20px rgba(0, 0, 0, 0.3)';
    
    // Instructions
    const instructions = document.createElement('div');
    instructions.className = 'instructions';
    instructions.innerHTML = `
      <h2 style="text-align: center; margin-bottom: 20px; color: black;">How to Play</h2>
      <p style="margin-bottom: 15px; line-height: 1.5; color: #FF5500;">Guide your phoenix through the fiery skies, avoiding flame helicopters and magma bats.</p>
      <p style="margin-bottom: 15px; line-height: 1.5; color: #FF5500;">Collect embers to gain XP and increase your level.</p>
      <p style="margin-bottom: 15px; line-height: 1.5; color: #FF5500;">Use your flaming trail to defeat enemies.</p>
      <div style="margin: 20px 0; display: flex; justify-content: space-between;">
        <div style="text-align: center; flex: 1;">
          <h3 style="margin-bottom: 10px; color: black;">Controls</h3>
          <p style="color: #FF5500;">Mouse or Touch: Move Phoenix</p>
        </div>
        <div style="text-align: center; flex: 1;">
          <h3 style="margin-bottom: 10px; color: black;">Goal</h3>
          <p style="color: #FF5500;">Survive and reach 100% progress</p>
        </div>
      </div>
    `;
    
    // Create WorldSelector component
    const worldSelectorContainer = document.createElement('div');
    worldSelectorContainer.id = 'world-selector';
    worldSelectorContainer.style.position = 'absolute';
    worldSelectorContainer.style.top = '40%';
    worldSelectorContainer.style.left = '50%';
    worldSelectorContainer.style.transform = 'translate(-50%, -50%)';
    worldSelectorContainer.style.width = '100%';
    worldSelectorContainer.style.maxWidth = '800px';
    worldSelectorContainer.style.zIndex = '201';
    // First append the essential elements to the DOM
    contentBox.appendChild(instructions);
    menuContainer.appendChild(contentBox);
    menuContainer.appendChild(worldSelectorContainer);
    this.container.appendChild(menuContainer);
    // Initialize React component for WorldSelector
    const root = ReactDOM.createRoot(worldSelectorContainer);
    root.render(React.createElement(WorldSelector, {
        onWorldSelect: (worldNumber) => {
            if (window.worldProgressionSystem) {
                window.worldProgressionSystem.setCurrentWorld(worldNumber);
            }
        },
        unlockedWorlds: window.worldProgressionSystem ? 
            window.worldProgressionSystem.getUnlockedWorlds() : [1]
    }));
    
    // Start button - positioned lower to make room for world indicator
    const startButton = document.createElement('button');
    startButton.className = 'start-button';
    startButton.textContent = 'START GAME';
    startButton.style.backgroundColor = 'black';
    startButton.style.color = '#FF5500';
    startButton.style.border = 'none';
    startButton.style.padding = '15px 40px';
    startButton.style.fontSize = '1.5rem';
    startButton.style.fontWeight = 'bold';
    startButton.style.borderRadius = '30px';
    startButton.style.cursor = 'pointer';
    startButton.style.transition = 'all 0.2s ease';
    startButton.style.boxShadow = '0 0 15px rgba(0, 0, 0, 0.7)';
    startButton.style.animation = 'pulse 2s infinite';
    startButton.style.marginTop = '0px';
    startButton.style.position = 'absolute';
    startButton.style.top = '70%';
    startButton.style.left = '50%';
    startButton.style.transform = 'translateX(-50%)';
    startButton.style.zIndex = '200';
    
    // Hover effects for start button
    startButton.addEventListener('mouseover', () => {
      startButton.style.backgroundColor = '#222222';
      startButton.style.transform = 'scale(1.05)';
    });
    
    startButton.addEventListener('mouseout', () => {
      startButton.style.backgroundColor = 'black';
      startButton.style.transform = 'scale(1)';
    });
    
    // Click event for start button with basic hide and start functionality
    startButton.addEventListener('click', () => {
      // Simply hide the menu - world1 will handle game start
      if (this.elements.menuContainer) {
        this.elements.menuContainer.style.opacity = '0';
        setTimeout(() => {
          this.hide();
        }, 500);
      }
    });
    
    // Store references to elements
    this.elements.menuContainer = menuContainer;
    this.elements.startButton = startButton;
    
    // Append elements to build the menu
    contentBox.appendChild(instructions);
    menuContainer.appendChild(contentBox);
    menuContainer.appendChild(startButton);
    
    // Append settings button to the container, not the menu
    // This ensures it's positioned correctly and visible
    this.container.appendChild(settingsButton);
    this.container.appendChild(menuContainer);
    
    // Store references to elements
    this.elements.menuContainer = menuContainer;
    this.elements.startButton = startButton;
    this.elements.settingsButton = settingsButton;
  }
  
  showSettingsModal() {
    // Create modal container
    const modalContainer = document.createElement('div');
    modalContainer.className = 'settings-modal';
    modalContainer.style.position = 'absolute';
    modalContainer.style.top = '0';
    modalContainer.style.left = '0';
    modalContainer.style.width = '100%';
    modalContainer.style.height = '100%';
    modalContainer.style.backgroundColor = 'rgba(0, 0, 0, 0.8)';
    modalContainer.style.display = 'flex';
    modalContainer.style.justifyContent = 'center';
    modalContainer.style.alignItems = 'center';
    modalContainer.style.zIndex = '2000'; // Increased z-index to ensure modal appears above all other elements
    modalContainer.style.opacity = '0';
    modalContainer.style.transition = 'opacity 0.3s ease';
    
    // Create modal content
    const modalContent = document.createElement('div');
    modalContent.className = 'settings-modal-content';
    modalContent.style.backgroundColor = 'rgba(40, 40, 40, 0.95)';
    modalContent.style.borderRadius = '10px';
    modalContent.style.padding = '20px';
    modalContent.style.width = '80%';
    modalContent.style.maxWidth = '400px';
    modalContent.style.border = '2px solid #FF5500';
    modalContent.style.boxShadow = '0 0 20px rgba(0, 0, 0, 0.5)';
    modalContent.style.transform = 'scale(0.9)';
    modalContent.style.transition = 'transform 0.3s ease';
    
    // Add responsive styles for modal on smaller screens
    const modalStyles = document.createElement('style');
    modalStyles.textContent = `
      @media (max-width: 600px) {
        .settings-modal-content {
          width: 90% !important;
          padding: 15px !important;
        }
        
        .settings-modal-content h2 {
          font-size: 18px !important;
          margin-bottom: 15px !important;
        }
        
        .settings-modal-content select,
        .settings-modal-content input {
          padding: 6px !important;
          font-size: 14px !important;
        }
        
        .settings-modal-content button {
          padding: 6px 15px !important;
          font-size: 14px !important;
        }
      }
    `;
    document.head.appendChild(modalStyles);
    
    // Modal title
    const modalTitle = document.createElement('h2');
    modalTitle.textContent = 'Game Settings';
    modalTitle.style.color = '#FF5500';
    modalTitle.style.textAlign = 'center';
    modalTitle.style.marginBottom = '20px';
    
    // Rank Level Setting
    const rankContainer = document.createElement('div');
    rankContainer.style.marginBottom = '15px';
    
    const rankLabel = document.createElement('label');
    rankLabel.textContent = 'Rank Level:';
    rankLabel.style.display = 'block';
    rankLabel.style.color = '#FF9955';
    rankLabel.style.marginBottom = '5px';
    
    const rankSelect = document.createElement('select');
    rankSelect.style.width = '100%';
    rankSelect.style.padding = '8px';
    rankSelect.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    rankSelect.style.color = '#FF5500';
    rankSelect.style.border = '1px solid #FF5500';
    rankSelect.style.borderRadius = '5px';
    
    // Add rank options (1-100)
    for (let i = 1; i <= 100; i++) {
      const option = document.createElement('option');
      option.value = i;
      option.textContent = `Rank ${i}`;
      rankSelect.appendChild(option);
    }
    
    // Set the current rank
    if (window.rankSystem) {
      rankSelect.value = window.rankSystem.getCurrentRank();
    }
    
    rankContainer.appendChild(rankLabel);
    rankContainer.appendChild(rankSelect);
    
    // XP Level Setting
    const xpContainer = document.createElement('div');
    xpContainer.style.marginBottom = '20px';
    
    const xpLabel = document.createElement('label');
    xpLabel.textContent = 'XP Amount:';
    xpLabel.style.display = 'block';
    xpLabel.style.color = '#FF9955';
    xpLabel.style.marginBottom = '5px';
    
    const xpInput = document.createElement('input');
    xpInput.type = 'number';
    xpInput.min = '0';
    xpInput.step = '100';
    xpInput.style.width = '100%';
    xpInput.style.padding = '8px';
    xpInput.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    xpInput.style.color = '#FF5500';
    xpInput.style.border = '1px solid #FF5500';
    xpInput.style.borderRadius = '5px';
    
    // Set the current XP
    if (window.rankSystem) {
      xpInput.value = window.rankSystem.currentXP;
    }
    
    xpContainer.appendChild(xpLabel);
    xpContainer.appendChild(xpInput);
    
    // Buttons container
    const buttonsContainer = document.createElement('div');
    buttonsContainer.style.display = 'flex';
    buttonsContainer.style.justifyContent = 'space-between';
    buttonsContainer.style.marginTop = '20px';
    
    // Save button
    const saveButton = document.createElement('button');
    saveButton.textContent = 'Save';
    saveButton.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    saveButton.style.color = '#FF5500';
    saveButton.style.border = '2px solid #FF5500';
    saveButton.style.borderRadius = '5px';
    saveButton.style.padding = '8px 20px';
    saveButton.style.cursor = 'pointer';
    saveButton.style.transition = 'all 0.2s ease';
    
    saveButton.addEventListener('mouseover', () => {
      saveButton.style.backgroundColor = 'rgba(40, 40, 40, 0.8)';
      saveButton.style.transform = 'scale(1.05)';
    });
    
    saveButton.addEventListener('mouseout', () => {
      saveButton.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
      saveButton.style.transform = 'scale(1)';
    });
    
    saveButton.addEventListener('click', () => {
      if (window.rankSystem) {
        const rankValue = parseInt(rankSelect.value);
        const xpValue = parseInt(xpInput.value);
        
        window.rankSystem.currentRank = rankValue;
        window.rankSystem.currentXP = xpValue;
        window.rankSystem.saveRankData();
        window.rankSystem.updateRankDisplay();
      }
      // Save world unlock states
      if (window.worldProgressionSystem) {
        const unlockedWorlds = [];
        for (let i = 1; i <= 5; i++) {
          const checkbox = document.getElementById(`world-${i}`);
          if (checkbox && checkbox.checked) {
            unlockedWorlds.push(i);
          }
        }
        // Update WorldProgressionSystem
        unlockedWorlds.forEach(worldNum => {
          window.worldProgressionSystem.unlockWorld(worldNum);
        });
      }
      
      closeModal();
    });
    
    // Cancel button
    const cancelButton = document.createElement('button');
    cancelButton.textContent = 'Cancel';
    cancelButton.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
    cancelButton.style.color = '#FF9955';
    cancelButton.style.border = '2px solid #FF9955';
    cancelButton.style.borderRadius = '5px';
    cancelButton.style.padding = '8px 20px';
    cancelButton.style.cursor = 'pointer';
    cancelButton.style.transition = 'all 0.2s ease';
    
    cancelButton.addEventListener('mouseover', () => {
      cancelButton.style.backgroundColor = 'rgba(40, 40, 40, 0.8)';
      cancelButton.style.transform = 'scale(1.05)';
    });
    
    cancelButton.addEventListener('mouseout', () => {
      cancelButton.style.backgroundColor = 'rgba(0, 0, 0, 0.7)';
      cancelButton.style.transform = 'scale(1)';
    });
    
    cancelButton.addEventListener('click', () => {
      closeModal();
    });
    
    buttonsContainer.appendChild(cancelButton);
    buttonsContainer.appendChild(saveButton);
    
    // Assemble the modal
    // Add worlds container for unlock status
    const worldsContainer = document.createElement('div');
    worldsContainer.style.marginBottom = '20px';
    worldsContainer.style.borderTop = '1px solid rgba(255, 85, 0, 0.3)';
    worldsContainer.style.paddingTop = '15px';
    const worldsLabel = document.createElement('label');
    worldsLabel.textContent = 'World Progress:';
    worldsLabel.style.display = 'block';
    worldsLabel.style.color = '#FF9955';
    worldsLabel.style.marginBottom = '10px';
    const worldsList = document.createElement('div');
    worldsList.style.display = 'flex';
    worldsList.style.flexDirection = 'column';
    worldsList.style.gap = '8px';
    // Create checkboxes for each world
    for (let i = 1; i <= 5; i++) {
        const worldRow = document.createElement('div');
        worldRow.style.display = 'flex';
        worldRow.style.alignItems = 'center';
        worldRow.style.gap = '10px';
        const checkbox = document.createElement('input');
        checkbox.type = 'checkbox';
        checkbox.id = `world-${i}`;
        checkbox.style.accentColor = '#FF5500';
        
        // Set initial checked state based on WorldProgressionSystem
        if (window.worldProgressionSystem) {
            checkbox.checked = window.worldProgressionSystem.isWorldUnlocked(i);
        }
        const label = document.createElement('label');
        label.htmlFor = `world-${i}`;
        label.textContent = `World ${i}`;
        label.style.color = '#FF9955';
        worldRow.appendChild(checkbox);
        worldRow.appendChild(label);
        worldsList.appendChild(worldRow);
    }
    worldsContainer.appendChild(worldsLabel);
    worldsContainer.appendChild(worldsList);
    modalContent.appendChild(modalTitle);
    modalContent.appendChild(rankContainer);
    modalContent.appendChild(xpContainer);
    modalContent.appendChild(worldsContainer);
    modalContent.appendChild(buttonsContainer);
    modalContainer.appendChild(modalContent);
    
    // Add to the DOM
    document.body.appendChild(modalContainer);
    
    // Close modal function
    const closeModal = () => {
      modalContainer.style.opacity = '0';
      modalContent.style.transform = 'scale(0.9)';
      
      setTimeout(() => {
        modalContainer.remove();
      }, 300);
    };
    
    // Animate modal in
    setTimeout(() => {
      modalContainer.style.opacity = '1';
      modalContent.style.transform = 'scale(1)';
    }, 10);
  }
  
  hide() {
    if (this.elements.menuContainer) {
      // Use opacity transition for smoother disappearance
      this.elements.menuContainer.style.opacity = '0';
      
      // Immediately hide settings button when the game starts
      if (this.elements.settingsButton) {
        // Hide the settings button instantly without delay
        this.elements.settingsButton.style.opacity = '0';
        this.elements.settingsButton.style.display = 'none';
      }
      
      // Wait for transition to complete before hiding
      setTimeout(() => {
        this.elements.menuContainer.style.display = 'none';
      }, 500); // Match the transition time from CSS
      
      // Also hide the rank bar when menu is hidden (game is starting)
      const rankBarElement = document.querySelector('.rank-bar-container');
      if (rankBarElement) {
        rankBarElement.style.opacity = '0';
        setTimeout(() => {
          rankBarElement.style.display = 'none';
        }, 500);
      }
      
      // Explicitly hide the start button
      this.hideStartButton();
    }
  }
  
  show() {
    if (this.elements.menuContainer) {
      // First make it visible but transparent
      this.elements.menuContainer.style.display = 'flex';
      
      // Make sure settings button is visible when going back to the menu
      if (this.elements.settingsButton) {
        this.elements.settingsButton.style.display = 'block';
        setTimeout(() => {
          this.elements.settingsButton.style.opacity = '1';
        }, 10);
      }
      
      // Force a reflow to ensure transition works
      setTimeout(() => {
        this.elements.menuContainer.style.opacity = '1';
      }, 10);
      
      // Also show the rank bar when menu is shown (back to menu)
      const rankBarElement = document.querySelector('.rank-bar-container');
      if (rankBarElement) {
        rankBarElement.style.display = 'flex';
        setTimeout(() => {
          rankBarElement.style.opacity = '1';
        }, 10);
      }
      
      // Ensure the start button is visible without forcing styles
      this.showStartButton();
    }
  }
  
  // Show menu without displaying rank bar and settings button
  showWithoutRankAndSettings() {
    if (this.elements.menuContainer) {
      // First make it visible but transparent
      this.elements.menuContainer.style.display = 'flex';
      
      // Keep settings button hidden
      if (this.elements.settingsButton) {
        this.elements.settingsButton.style.display = 'none';
        this.elements.settingsButton.style.opacity = '0';
      }
      
      // Force a reflow to ensure transition works
      setTimeout(() => {
        this.elements.menuContainer.style.opacity = '1';
      }, 10);
      
      // Ensure the rank bar stays hidden
      const rankBarElement = document.querySelector('.rank-bar-container');
      if (rankBarElement) {
        rankBarElement.style.opacity = '0';
        rankBarElement.style.display = 'none';
      }
      
      // Ensure the start button is visible
      this.showStartButton();
    }
  }
  
  // Method to explicitly show the start button
  showStartButton() {
    if (this.elements.startButton) {
      this.elements.startButton.style.display = 'block';
      this.elements.startButton.style.opacity = '1';
      this.elements.startButton.style.transform = 'scale(1)';
      this.elements.startButton.style.animation = 'pulse 2s infinite';
    }
  }
  
  // Method to explicitly hide the start button
  hideStartButton() {
    if (this.elements.startButton) {
      this.elements.startButton.style.display = 'none';
      this.elements.startButton.style.opacity = '0';
    }
  }
}