export class Phoenix {
  constructor(x, y, particleSystem) {
    this.x = x;
    this.y = y;
    this.targetX = x;
    this.targetY = y;
    this.width = 40;
    this.height = 60;
    this.particleSystem = particleSystem;
    this.maxHealth = 100;
    this.health = this.maxHealth;
    this.invulnerableTime = 0;
    this.invulnerableDuration = 1.5; // Seconds of invulnerability after being hit
    this.flameTimer = 0;
    this.trailTimer = 0;
    this.wingTimer = 0;
    this.wingAngle = 0;
    this.wingDirection = 1;
    this.bodyParticles = [];
    this.wingParticles = [];
    this.tailParticles = [];
    this.trailPoints = []; // Store points for trail
    this.trailLength = 40; // Increased from default 20
    this.trailHeatRadius = 70; // Radius of heat damage area
    
    // Damage animation properties
    this.damageFlashTimer = 0;
    this.damageFlashDuration = 0.5; // Duration in seconds
    this.damageShockwaveActive = false;
    this.damageShockwaveRadius = 0;
    this.damageShockwaveMaxRadius = 100;
    this.damageShockwaveSpeed = 200; // Pixels per second
    
    // Near-miss warning properties
    this.nearMissTimer = 0;
    this.nearMissDuration = 0.3; // Duration in seconds
    this.nearMissIntensity = 0; // Current intensity of the warning effect
    this.flameColors = [
      { h: 15, s: 100, l: 60 },  // Deep orange
      { h: 30, s: 100, l: 70 },  // Orange
      { h: 45, s: 100, l: 75 },  // Gold
      { h: 60, s: 100, l: 80 },  // Yellow
    ];
    
    // Initialize body particles
    this.initializeBodyParticles();
  }
  
  initializeBodyParticles() {
    // Clear existing particles
    this.bodyParticles = [];
    this.wingParticles = [];
    this.tailParticles = [];
    
    // Create phoenix body shape
    for (let i = 0; i < 25; i++) {
      this.bodyParticles.push({
        offsetX: (Math.random() - 0.5) * 15,
        offsetY: (Math.random() - 0.5) * 25,
        size: 3 + Math.random() * 4,
        color: this.getRandomFlameColor(),
        phase: Math.random() * Math.PI * 2,
        speed: 0.5 + Math.random() * 2
      });
    }
    
    // Create wing particles (left and right wings)
    for (let side = -1; side <= 1; side += 2) {
      for (let i = 0; i < 15; i++) {
        const distance = 10 + Math.random() * 25;
        const angle = (Math.random() * 0.5 + 0.25) * Math.PI; // Wing angle range
        
        this.wingParticles.push({
          side: side,
          distance: distance,
          angle: angle,
          baseAngle: angle,
          size: 3 + Math.random() * 4,
          color: this.getRandomFlameColor(),
          phase: Math.random() * Math.PI * 2,
          speed: 0.5 + Math.random() * 2
        });
      }
    }
    
    // Create tail particles
    for (let i = 0; i < 20; i++) {
      const distance = 15 + i * 1.5;
      const spread = 5 + i * 0.5;
      
      this.tailParticles.push({
        distance: distance,
        offsetX: (Math.random() - 0.5) * spread,
        size: 4 + Math.random() * 3 - i * 0.1,
        color: this.getRandomFlameColor(),
        phase: Math.random() * Math.PI * 2,
        speed: 0.5 + Math.random() * 2
      });
    }
  }
  
  getRandomFlameColor() {
    const colorIdx = Math.floor(Math.random() * this.flameColors.length);
    const color = this.flameColors[colorIdx];
    
    // Add slight variation
    const h = color.h + (Math.random() - 0.5) * 10;
    const s = color.s;
    const l = color.l + (Math.random() - 0.5) * 15;
    
    return `hsl(${h}, ${s}%, ${l}%)`;
  }
  
  update(deltaTime) {
    // Smooth movement toward target (both X and Y)
    const dx = this.targetX - this.x;
    const dy = this.targetY - this.y;
    this.x += dx * 5 * deltaTime;
    this.y += dy * 5 * deltaTime;
    
    // Update damage flash animation if active
    if (this.damageFlashTimer > 0) {
      this.damageFlashTimer -= deltaTime;
    }
    
    // Update invulnerability timer
    if (this.invulnerableTime > 0) {
      this.invulnerableTime -= deltaTime;
    }
    
    // Update shockwave animation if active
    if (this.damageShockwaveActive) {
      this.damageShockwaveRadius += this.damageShockwaveSpeed * deltaTime;
      
      if (this.damageShockwaveRadius >= this.damageShockwaveMaxRadius) {
        this.damageShockwaveActive = false;
      }
    }
    
    // Update near-miss warning effect if active
    if (this.nearMissTimer > 0) {
      this.nearMissTimer -= deltaTime;
      
      // Calculate intensity - starts strong and fades out
      this.nearMissIntensity = this.nearMissTimer / this.nearMissDuration;
    } else {
      this.nearMissIntensity = 0;
    }
    
    // Update wing animation
    this.wingTimer += deltaTime;
    if (this.wingTimer > 0.05) {
      this.wingAngle += 0.1 * this.wingDirection;
      
      if (this.wingAngle > 0.4) {
        this.wingDirection = -1;
      } else if (this.wingAngle < -0.2) {
        this.wingDirection = 1;
      }
      
      this.wingTimer = 0;
    }
    
    // Store trail points
    this.trailPoints.unshift({ 
      x: this.x, 
      y: this.y,
      time: Date.now() // Store timestamp for each point
    });
    if (this.trailPoints.length > this.trailLength) {
      this.trailPoints.pop();
    }
    
    // Emit flame particles around the body
    this.flameTimer += deltaTime;
    if (this.flameTimer > 0.03) {
      for (let i = 0; i < 2; i++) {
        // Body flames
        this.particleSystem.createFlame(
          this.x + (Math.random() - 0.5) * 30,
          this.y + (Math.random() - 0.5) * 40
        );
        
        // Trail flames
        if (this.trailPoints.length > 5) {
          const trailIdx = 5 + Math.floor(Math.random() * (this.trailPoints.length - 5));
          const trailPoint = this.trailPoints[trailIdx];
          this.particleSystem.createFlame(
            trailPoint.x + (Math.random() - 0.5) * 15,
            trailPoint.y + (Math.random() - 0.5) * 15
          );
        }
      }
      this.flameTimer = 0;
    }
    
    // Emit trail particles
    this.trailTimer += deltaTime;
    if (this.trailTimer > 0.05) {
      // Main trail
      this.particleSystem.createSmoke(
        this.x + (Math.random() - 0.5) * 10,
        this.y + 30 + (Math.random() - 0.5) * 10
      );
      
      // Trail from specific points
      if (this.trailPoints.length > 10) {
        const trailIdx = Math.floor(Math.random() * Math.min(10, this.trailPoints.length));
        const trailPoint = this.trailPoints[trailIdx];
        this.particleSystem.createSmoke(
          trailPoint.x + (Math.random() - 0.5) * 20,
          trailPoint.y + (Math.random() - 0.5) * 10
        );
      }
      
      this.trailTimer = 0;
    }
  }
  
  draw(ctx) {
    // Draw near-miss warning glow behind everything
    if (this.nearMissIntensity > 0) {
      this.drawNearMissWarning(ctx);
    }
    
    // Draw shockwave if active
    if (this.damageShockwaveActive) {
      this.drawShockwave(ctx);
    }
    
    // Draw trail flame effect
    this.drawTrail(ctx);
    
    // Draw the phoenix body particles
    this.drawBodyParticles(ctx);
    
    // Draw wings
    this.drawWings(ctx);
    
    // Draw tail
    this.drawTail(ctx);
  }
  
  // Draw the shockwave effect
  drawShockwave(ctx) {
    const opacity = 1 - (this.damageShockwaveRadius / this.damageShockwaveMaxRadius);
    const gradient = ctx.createRadialGradient(
      this.x, this.y, 0,
      this.x, this.y, this.damageShockwaveRadius
    );
    
    gradient.addColorStop(0, `rgba(255, 255, 255, 0)`);
    gradient.addColorStop(0.2, `rgba(255, 200, 50, ${opacity * 0.1})`);
    gradient.addColorStop(0.5, `rgba(255, 100, 0, ${opacity * 0.3})`);
    gradient.addColorStop(0.8, `rgba(255, 50, 0, ${opacity * 0.2})`);
    gradient.addColorStop(1, `rgba(255, 0, 0, 0)`);
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.damageShockwaveRadius, 0, Math.PI * 2);
    ctx.fill();
    
    // Draw ring at the edge of the shockwave
    ctx.strokeStyle = `rgba(255, 50, 0, ${opacity * 0.7})`;
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.damageShockwaveRadius, 0, Math.PI * 2);
    ctx.stroke();
  }
  
  // Draw the near-miss warning effect
  drawNearMissWarning(ctx) {
    // Create a yellow-orange glow around the phoenix
    const intensity = this.nearMissIntensity;
    const glowSize = 30 + 20 * Math.sin(Date.now() / 100); // Pulsating size
    
    // Create radial gradient for warning glow
    const gradient = ctx.createRadialGradient(
      this.x, this.y, this.width / 2,
      this.x, this.y, glowSize
    );
    
    gradient.addColorStop(0, `rgba(255, 255, 0, ${intensity * 0.1})`);
    gradient.addColorStop(0.5, `rgba(255, 200, 0, ${intensity * 0.15})`);
    gradient.addColorStop(1, `rgba(255, 150, 0, 0)`);
    
    ctx.fillStyle = gradient;
    ctx.beginPath();
    ctx.arc(this.x, this.y, glowSize, 0, Math.PI * 2);
    ctx.fill();
    
    // Add a subtle yellow stroke around phoenix
    ctx.strokeStyle = `rgba(255, 255, 0, ${intensity * 0.4})`;
    ctx.lineWidth = 3 * intensity;
    ctx.beginPath();
    ctx.arc(this.x, this.y, this.width / 2 + 5, 0, Math.PI * 2);
    ctx.stroke();
    
    // Add subtle lightning-like arcs around the phoenix
    ctx.strokeStyle = `rgba(255, 255, 100, ${intensity * 0.6})`;
    ctx.lineWidth = 1;
    
    const arcs = 5;
    for (let i = 0; i < arcs; i++) {
      const startAngle = (Math.PI * 2 * i / arcs) + (Date.now() / 500);
      const arcLength = Math.PI / 4 + (Math.PI / 6) * Math.sin(Date.now() / 300 + i);
      
      ctx.beginPath();
      ctx.arc(this.x, this.y, this.width / 2 + 12, startAngle, startAngle + arcLength);
      ctx.stroke();
    }
  }
  
  drawTrail(ctx) {
    if (this.trailPoints.length < 2) return;
    
    // Draw heat radiation glow under the trail
    this.drawTrailHeatGlow(ctx);
    
    // Draw a fading trail connecting previous positions
    for (let i = 1; i < this.trailPoints.length; i++) {
      const p1 = this.trailPoints[i-1];
      const p2 = this.trailPoints[i];
      
      // Create gradient between points
      const gradient = ctx.createLinearGradient(p1.x, p1.y, p2.x, p2.y);
      const alpha = 1 - (i / this.trailPoints.length);
      
      gradient.addColorStop(0, `rgba(255, 120, 50, ${alpha * 0.4})`);
      gradient.addColorStop(1, `rgba(255, 150, 20, ${alpha * 0.2})`);
      
      ctx.strokeStyle = gradient;
      ctx.lineWidth = 22 * (1 - i / this.trailPoints.length); // Wider trail
      ctx.beginPath();
      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
    }
  }
  
  drawTrailHeatGlow(ctx) {
    // Draw heat radiation effect
    for (let i = 0; i < this.trailPoints.length; i += 2) { // Skip every other point for performance
      const point = this.trailPoints[i];
      if (!point) continue;
      
      // Calculate age of this trail point
      const pointAge = (Date.now() - point.time) / 1000; // Age in seconds
      
      // Skip if too old
      if (pointAge > 1.5) continue;
      
      // Calculate intensity based on position in trail and age
      const intensity = 1 - (i / this.trailPoints.length) - (pointAge * 0.5);
      if (intensity <= 0) continue;
      
      // Draw heat glow
      const radius = this.trailHeatRadius * (0.5 + intensity * 0.5);
      const gradient = ctx.createRadialGradient(
        point.x, point.y, 0,
        point.x, point.y, radius
      );
      
      gradient.addColorStop(0, `rgba(255, 200, 70, ${intensity * 0.15})`);
      gradient.addColorStop(0.4, `rgba(255, 100, 0, ${intensity * 0.08})`);
      gradient.addColorStop(1, 'rgba(255, 0, 0, 0)');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(point.x, point.y, radius, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  
  // Check if a point is within the heat radius of this trail point
  isPointInHeatRadius(x, y, point) {
    const dx = point.x - x;
    const dy = point.y - y;
    const distance = Math.sqrt(dx * dx + dy * dy);
    
    // Calculate heat radius based on point age
    const pointAge = (Date.now() - point.time) / 1000; // Age in seconds
    if (pointAge > 1.5) return false; // Too old to cause damage
    
    // Intensity decreases with age
    const intensity = 1 - (pointAge * 0.5);
    if (intensity <= 0) return false;
    
    // Calculate effective radius based on intensity
    const effectiveRadius = this.trailHeatRadius * (0.5 + intensity * 0.5);
    
    return distance < effectiveRadius;
  }
  
  drawBodyParticles(ctx) {
    // Animate and draw body particles
    for (const p of this.bodyParticles) {
      const time = Date.now() / 1000;
      const oscX = Math.sin(time * p.speed + p.phase) * 3;
      const oscY = Math.cos(time * p.speed + p.phase) * 3;
      
      const x = this.x + p.offsetX + oscX;
      const y = this.y + p.offsetY + oscY;
      
      const glowSize = p.size * (1.2 + Math.sin(time * 2 + p.phase) * 0.2);
      
      // Modify color and size for damage flash
      let particleColor = p.color;
      let sizeFactor = 1;
      
      if (this.damageFlashTimer > 0) {
        // Calculate flash intensity (1.0 to 0.0 over the flash duration)
        const flashIntensity = this.damageFlashTimer / this.damageFlashDuration;
        
        // Flash to red color
        particleColor = this.damageFlashTimer > 0.25 * this.damageFlashDuration ? 
                        'rgba(255, 0, 0, 0.9)' : p.color;
        
        // Make particles pulse outward during damage
        sizeFactor = 1 + flashIntensity * 0.5;
      }
      
      // Draw glow
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, glowSize * 2 * sizeFactor);
      gradient.addColorStop(0, particleColor);
      gradient.addColorStop(1, 'rgba(255, 100, 0, 0)');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, glowSize * 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Draw particle core
      ctx.fillStyle = 'rgba(255, 255, 200, 0.8)';
      ctx.beginPath();
      ctx.arc(x, y, p.size / 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  
  drawWings(ctx) {
    // Draw and animate wing particles
    for (const p of this.wingParticles) {
      const time = Date.now() / 1000;
      const wingAngle = p.baseAngle + this.wingAngle;
      
      const x = this.x + Math.cos(wingAngle) * p.distance * p.side;
      const y = this.y + Math.sin(wingAngle) * p.distance;
      
      const oscSize = p.size * (1 + Math.sin(time * p.speed + p.phase) * 0.3);
      
      // Modify color and size for damage flash
      let particleColor = p.color;
      let sizeFactor = 1;
      
      if (this.damageFlashTimer > 0) {
        // Calculate flash intensity (1.0 to 0.0 over the flash duration)
        const flashIntensity = this.damageFlashTimer / this.damageFlashDuration;
        
        // Flash to red color
        particleColor = this.damageFlashTimer > 0.25 * this.damageFlashDuration ? 
                        'rgba(255, 0, 0, 0.9)' : p.color;
        
        // Make particles pulse outward during damage
        sizeFactor = 1 + flashIntensity * 0.5;
      }
      
      // Draw glow
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, oscSize * 2 * sizeFactor);
      gradient.addColorStop(0, particleColor);
      gradient.addColorStop(1, 'rgba(255, 100, 0, 0)');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, oscSize * 2, 0, Math.PI * 2);
      ctx.fill();
      
      // Draw particle core
      ctx.fillStyle = 'rgba(255, 255, 200, 0.8)';
      ctx.beginPath();
      ctx.arc(x, y, oscSize / 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  
  drawTail(ctx) {
    // Draw and animate tail particles
    for (const p of this.tailParticles) {
      const time = Date.now() / 1000;
      const oscX = Math.sin(time * p.speed + p.phase) * 2;
      
      const x = this.x + p.offsetX + oscX;
      const y = this.y + p.distance;
      
      const oscSize = p.size * (1 + Math.sin(time * p.speed + p.phase) * 0.3);
      
      // Modify color and size for damage flash
      let particleColor = p.color;
      let sizeFactor = 1;
      
      if (this.damageFlashTimer > 0) {
        // Calculate flash intensity (1.0 to 0.0 over the flash duration)
        const flashIntensity = this.damageFlashTimer / this.damageFlashDuration;
        
        // Flash to red color
        particleColor = this.damageFlashTimer > 0.25 * this.damageFlashDuration ? 
                        'rgba(255, 0, 0, 0.9)' : p.color;
        
        // Make particles pulse outward during damage
        sizeFactor = 1 + flashIntensity * 0.5;
      }
      
      // Draw glow
      const gradient = ctx.createRadialGradient(x, y, 0, x, y, oscSize * 2 * sizeFactor);
      gradient.addColorStop(0, particleColor);
      gradient.addColorStop(1, 'rgba(255, 100, 0, 0)');
      
      ctx.fillStyle = gradient;
      ctx.beginPath();
      ctx.arc(x, y, oscSize * 2, 0, Math.PI * 2);
      ctx.fill();
    }
  }
  
  // Trigger damage animation and apply damage
  takeDamage(amount = 25) {
    // Don't take damage if invulnerable
    if (this.invulnerableTime > 0) {
      return false;
    }
    
    // Apply damage
    this.health = Math.max(0, this.health - amount);
    
    // Start damage flash
    this.damageFlashTimer = this.damageFlashDuration;
    
    // Start shockwave
    this.damageShockwaveActive = true;
    this.damageShockwaveRadius = 0;
    
    // Make player invulnerable briefly
    this.invulnerableTime = this.invulnerableDuration;
    
    // Create explosion particles
    for (let i = 0; i < 15; i++) {
      const angle = Math.random() * Math.PI * 2;
      const distance = 10 + Math.random() * 30;
      const x = this.x + Math.cos(angle) * distance;
      const y = this.y + Math.sin(angle) * distance;
      
      this.particleSystem.createEmber(x, y);
    }
    
    // Return whether the phoenix died
    return this.health <= 0;
  }
  
  // Get health percentage
  getHealthPercent() {
    return this.health / this.maxHealth;
  }
  
  // Heal the phoenix
  heal(amount) {
    this.health = Math.min(this.maxHealth, this.health + amount);
  }
  
  // Trigger near-miss warning effect
  triggerNearMiss() {
    // Only trigger if not already showing a stronger effect (damage)
    if (this.damageFlashTimer <= 0) {
      this.nearMissTimer = this.nearMissDuration;
      
      // Add a few subtle particles for near-miss visualization
      for (let i = 0; i < 3; i++) {
        const angle = Math.random() * Math.PI * 2;
        const distance = 20 + Math.random() * 10;
        const x = this.x + Math.cos(angle) * distance;
        const y = this.y + Math.sin(angle) * distance;
        
        this.particleSystem.createEmber(x, y);
      }
    }
  }
}