/**
 * UI Class - Manages all game interface elements
 * 
 * This class handles three main categories of UI elements:
 * 
 * 1. Gameplay UI - Shows during active gameplay:
 *    - Health bar
 *    - XP and level indicators
 *    - Progress and time displays
 *    - Altitude meter
 * 
 * 2. Game Over Screen - Shows when player dies:
 *    - Stats summary (altitude, time, XP)
 *    - Rank progress information
 *    - Restart button with animations
 * 
 * 3. World Complete Screen - Shows when player completes a world:
 *    - Time and XP statistics
 *    - Phoenix Gems earned
 *    - Rank progress information
 *    - Continue button with animations
 * 
 * The UI dynamically adapts to the current game state to show only relevant information.
 */
export class UI {
  constructor(ctx, gameState, phoenix) {
    this.ctx = ctx;
    this.gameState = gameState;
    this.phoenix = phoenix;
    this.gameOverStartTime = null;
    this.worldCompleteStartTime = null;
    this.buttonPulseTime = 0;
    this.lastXPAmount = 0; // Track last XP amount to detect changes
    this.lastRankUpdateTime = 0; // Throttle rank updates
  }
  
  /**
   * Main draw method for UI - handles all UI rendering based on game state
   * @param {number} width - Canvas width
   * @param {number} height - Canvas height
   */
  draw(width, height) {
    this.ctx.font = '18px Arial';
    this.ctx.fillStyle = 'black';
    
    // Get rank information if available
    const rankSystem = window.rankSystem;
    const rankInfo = rankSystem ? {
      currentRank: rankSystem.getCurrentRank(),
      progress: rankSystem.getRankProgress(),
      currentXP: rankSystem.currentXP,
      neededXP: rankSystem.getXPForNextRank()
    } : null;
    
    // Check if XP has changed and update rank display
    // Limit updates to once per second to avoid excessive DOM updates
    if (this.lastXPAmount !== this.gameState.xp && Date.now() - this.lastRankUpdateTime > 1000) {
      this.updateRankDisplayOnXPGain();
      this.lastXPAmount = this.gameState.xp;
      this.lastRankUpdateTime = Date.now();
    }
    
    // Get current minutes and seconds for various displays
    const minutes = Math.floor(this.gameState.survivalTime / 60);
    const seconds = Math.floor(this.gameState.survivalTime % 60);
    
    /* ===== GAMEPLAY UI SECTION ===== */
    // Only show gameplay UI if the game is active (not on menu, not game over, not world complete)
    // We consider the game active when the phoenix is alive and the game is not in a completion state
    // AND the game is actually running (not on main menu)
    const isGameActive = this.phoenix && 
                        this.phoenix.health > 0 && 
                        !this.gameState.gameOver && 
                        !this.gameState.worldComplete &&
                        window.gameInstance && 
                        window.gameInstance.isRunning;
    
    if (isGameActive) {
      // Check if rank bar is visible to determine proper positioning
      const rankBarElement = document.querySelector('.rank-bar-container');
      let yOffset = 30; // Default position
      
      if (rankBarElement) {
        const rankBarVisible = rankBarElement.style.display !== 'none' && 
                               parseFloat(getComputedStyle(rankBarElement).opacity) > 0.1;
        const rankBarRect = rankBarElement.getBoundingClientRect();
        
        if (rankBarVisible && rankBarRect.height > 0) {
          // Position further below the rank bar with more padding
          yOffset = rankBarRect.bottom + 30; // Increased from 10 to 30px
        }
      }
      
      // XP and Level
      this.ctx.textAlign = 'left';
      this.ctx.fillText(`Level: ${this.gameState.level}`, 20, yOffset);
      
      // XP Bar
      const xpBarWidth = 200;
      const xpBarHeight = 15;
      const xpFillWidth = (this.gameState.xp / this.gameState.xpToNextLevel) * xpBarWidth;
      
      this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
      this.ctx.fillRect(20, yOffset + 10, xpBarWidth, xpBarHeight);
      
      this.ctx.fillStyle = 'rgba(255, 150, 0, 0.8)';
      this.ctx.fillRect(20, yOffset + 10, xpFillWidth, xpBarHeight);
      
      this.ctx.strokeStyle = 'black';
      this.ctx.lineWidth = 1;
      this.ctx.strokeRect(20, yOffset + 10, xpBarWidth, xpBarHeight);
      
      // Health Bar
      this.drawHealthBar(20, yOffset + 40, 200, 15, this.phoenix.getHealthPercent());
      
      // Altitude, Time, and Progress moved to bottom of screen
      this.ctx.textAlign = 'right';
      
      // Calculate the bottom position with some padding
      const bottomPadding = 30;
      const indicatorHeight = 25; // Height for each indicator
      const indicatorSpacing = 30; // Spacing between indicators
      
      // Calculate text widths to determine the appropriate background width
      this.ctx.save();
      this.ctx.font = '18px Arial'; // Ensure font is set before measuring
      
      // Get the text for each indicator
      const altitudeText = `Altitude: ${Math.abs(Math.floor(this.gameState.altitude))}m`;
      const timeText = `Time: ${minutes}:${seconds.toString().padStart(2, '0')}`;
      const totalLevelTime = this.gameState.getTotalLevelTime();
      const progressPercent = Math.min(100, (this.gameState.survivalTime / totalLevelTime) * 100);
      const progressText = `Progress: ${progressPercent.toFixed(1)}%`;
      
      // Measure each text width
      const altitudeWidth = this.ctx.measureText(altitudeText).width;
      const timeWidth = this.ctx.measureText(timeText).width;
      const progressWidth = this.ctx.measureText(progressText).width;
      
      // Find the longest text width
      const maxTextWidth = Math.max(altitudeWidth, timeWidth, progressWidth);
      
      // Add padding to the width
      const indicatorWidth = maxTextWidth + 40; // 20px padding on each side
      
      this.ctx.restore();
      
      // Draw semi-transparent background for all three indicators with border
      this.ctx.fillStyle = 'rgba(0, 0, 0, 0.5)'; // Reduced opacity to 0.5
      this.ctx.beginPath();
      this.ctx.roundRect(
        width - indicatorWidth + 30, // Moved right by 40px (10+30) to give more space on right side
        height - bottomPadding - (3 * indicatorSpacing) + 5, // Moved up slightly
        indicatorWidth - 10, // Reduced width by 10px to better fit text
        3 * indicatorHeight + 20, // Increased height by 20px for more space at the bottom
        8
      );
      this.ctx.fill();
      
      // Add border around the background
      this.ctx.strokeStyle = 'rgba(255, 85, 0, 0.7)'; // Orange border matching game theme
      this.ctx.lineWidth = 2;
      this.ctx.stroke();
      
      // Set text color for better contrast against background
      this.ctx.fillStyle = 'white';
      
      // World Progress - based on time rather than altitude
      // Reuse the previously declared totalLevelTime and progressPercent variable
      this.ctx.fillText(`Progress: ${progressPercent.toFixed(1)}%`, width - 20, height - bottomPadding - 5);
      
      // Time (positioned above progress)
      this.ctx.fillText(`Time: ${minutes}:${seconds.toString().padStart(2, '0')}`, width - 20, height - bottomPadding - indicatorSpacing - 5);
      
      // Altitude (positioned above time)
      this.ctx.fillText(`Altitude: ${Math.abs(Math.floor(this.gameState.altitude))}m`, width - 20, height - bottomPadding - (2 * indicatorSpacing) - 5);
    }
    
    /* ===== GAME OVER SCREEN SECTION ===== */
    // Appears when phoenix health reaches zero
    // Shows game statistics and restart button
    if (this.gameState.gameOver) {
      // Store game over start time if it just became game over
      if (!this.gameOverStartTime && this.gameState.gameOver) {
        this.gameOverStartTime = Date.now();
        this.buttonPulseTime = 0;
        
        // Hide pause button when game ends
        if (window.gameInstance && window.gameInstance.pauseButton) {
          window.gameInstance.pauseButton.hide();
        }
      }
      
      // Calculate fade-in opacity (0 to 1 over 800ms)
      const timeSinceGameOver = Date.now() - (this.gameOverStartTime || 0);
      const fadeOpacity = Math.min(1, timeSinceGameOver / 800);
      
      // Dark semi-transparent background with fade-in
      this.ctx.fillStyle = `rgba(0, 0, 0, ${0.85 * fadeOpacity})`;
      this.ctx.fillRect(0, 0, width, height);
      
      // Draw a stylized container
      const containerWidth = Math.min(400, width * 0.8);
      const containerHeight = 320;
      const containerX = width / 2 - containerWidth / 2;
      const containerY = height / 2 - containerHeight / 2;
      
      // Background panel
      this.ctx.fillStyle = 'rgba(40, 40, 40, 0.8)';
      this.roundRect(containerX, containerY, containerWidth, containerHeight, 15, true);
      
      // Border
      this.ctx.strokeStyle = '#FF5500';
      this.ctx.lineWidth = 3;
      this.roundRect(containerX, containerY, containerWidth, containerHeight, 15, false, true);
      
      // Title
      this.ctx.fillStyle = '#FF5500';
      this.ctx.textAlign = 'center';
      this.ctx.font = width < 400 ? '26px Arial' : '34px Arial';
      this.ctx.fillText('GAME OVER', width / 2, containerY + 50);
      
      // Stats with improved visual hierarchy
      const textX = width / 2;
      const fontSize = width < 400 ? 16 : 18;
      this.ctx.font = `${fontSize}px Arial`;
      
      // Stats labels in dark color
      this.ctx.fillStyle = '#FF5500';
      this.ctx.fillText('Altitude Reached:', textX, containerY + 90);
      this.ctx.fillText('Survival Time:', textX, containerY + 120);
      this.ctx.fillText('Progress:', textX, containerY + 150);
      this.ctx.fillText('XP Gained:', textX, containerY + 180);
      
      // Stats values in brighter color
      this.ctx.fillStyle = 'rgba(255, 200, 100, 0.9)';
      this.ctx.fillText(`${Math.abs(Math.floor(this.gameState.altitude))}m`, textX, containerY + 105);
      this.ctx.fillText(`${minutes}:${seconds.toString().padStart(2, '0')}`, textX, containerY + 135);
      
      // Calculate and display progress percentage
      const totalLevelTime = this.gameState.getTotalLevelTime();
      const progressPercent = Math.min(100, (this.gameState.survivalTime / totalLevelTime) * 100);
      this.ctx.fillText(`${progressPercent.toFixed(1)}%`, textX, containerY + 165);
      
      this.ctx.fillText(`${this.gameState.xp}`, textX, containerY + 200);
      
      // Draw rank progress if rank system is available
      if (rankSystem) {
        this.drawRankProgress(textX, containerY + 230, containerWidth * 0.8, 20, rankInfo);
      }
      
      // Add Exit to Menu button under Restart button
      // Calculate button pulse effect (grows and shrinks) for the menu button
      const menuButtonPulseTime = this.buttonPulseTime - 0.3; // Offset timing for visual interest
      const menuPulseFactor = 1 + Math.sin(menuButtonPulseTime) * 0.06; // Slightly less pulse than restart
      
      // Calculate button pulse effect (grows and shrinks)
      this.buttonPulseTime = (this.buttonPulseTime || 0) + 0.05;
      const pulseFactor = 1 + Math.sin(this.buttonPulseTime) * 0.08; // Pulse between 0.92 and 1.08 size
      
      // Apply fade-in to buttons as well
      const buttonOpacity = Math.min(1, (timeSinceGameOver - 400) / 600); // Start button fade slightly later
      
      // Restart button (black with orange text)
      const buttonWidth = Math.min(200, containerWidth * 0.7);
      const buttonHeight = 40;
      const buttonX = width / 2 - (buttonWidth * pulseFactor) / 2;
      const buttonY = containerY + containerHeight - 70 - ((pulseFactor - 1) * buttonHeight) / 2;
      
      // Button background with fade-in and pulse
      this.ctx.fillStyle = `rgba(0, 0, 0, ${buttonOpacity})`;
      this.roundRect(buttonX, buttonY, buttonWidth * pulseFactor, buttonHeight * pulseFactor, 20, true);
      
      // Button border with glow effect
      const glowWidth = 2 + Math.sin(this.buttonPulseTime * 2) * 1;
      this.ctx.strokeStyle = `rgba(255, 85, 0, ${buttonOpacity})`;
      this.ctx.lineWidth = glowWidth;
      this.roundRect(buttonX, buttonY, buttonWidth * pulseFactor, buttonHeight * pulseFactor, 20, false, true);
      
      // Button text with fade-in
      this.ctx.fillStyle = `rgba(255, 85, 0, ${buttonOpacity})`;
      this.ctx.font = '18px Arial';
      this.ctx.fillText('RESTART', width / 2, buttonY + 25 * pulseFactor);
      
      // Removed tap instruction text
      
      // Exit to Menu button (smaller, positioned below restart button)
      const menuButtonWidth = Math.min(180, containerWidth * 0.6);
      const menuButtonHeight = 35;
      const menuButtonX = width / 2 - (menuButtonWidth * menuPulseFactor) / 2;
      const menuButtonY = buttonY + buttonHeight * pulseFactor + 15; // Position below restart button
      
      // Menu button background with fade-in and pulse
      this.ctx.fillStyle = `rgba(40, 40, 40, ${buttonOpacity})`;
      this.roundRect(menuButtonX, menuButtonY, menuButtonWidth * menuPulseFactor, menuButtonHeight * menuPulseFactor, 15, true);
      
      // Menu button border with glow effect
      const menuGlowWidth = 1.5 + Math.sin(menuButtonPulseTime * 2) * 0.8;
      this.ctx.strokeStyle = `rgba(255, 200, 100, ${buttonOpacity})`;
      this.ctx.lineWidth = menuGlowWidth;
      this.roundRect(menuButtonX, menuButtonY, menuButtonWidth * menuPulseFactor, menuButtonHeight * menuPulseFactor, 15, false, true);
      
      // Menu button text with fade-in
      this.ctx.fillStyle = `rgba(255, 200, 100, ${buttonOpacity})`;
      this.ctx.font = '16px Arial';
      this.ctx.fillText('EXIT TO MENU', width / 2, menuButtonY + 23 * menuPulseFactor);
    }
    
    /* ===== WORLD COMPLETE SCREEN SECTION ===== */
    // Appears when player successfully completes a level
    // Shows statistics, rewards and continue button
    if (this.gameState.worldComplete) {
      // Store world complete start time if it just became world complete
      if (!this.worldCompleteStartTime && this.gameState.worldComplete) {
        this.worldCompleteStartTime = Date.now();
        this.buttonPulseTime = 0;
        
        // Hide pause button when world is complete
        if (window.gameInstance && window.gameInstance.pauseButton) {
          window.gameInstance.pauseButton.hide();
        }
      }
      
      // Calculate fade-in opacity (0 to 1 over 800ms)
      const timeSinceComplete = Date.now() - (this.worldCompleteStartTime || 0);
      const fadeOpacity = Math.min(1, timeSinceComplete / 800);
      
      // Dark semi-transparent background with fade-in
      this.ctx.fillStyle = `rgba(0, 0, 0, ${0.85 * fadeOpacity})`;
      this.ctx.fillRect(0, 0, width, height);
      
      // Draw a stylized container
      const containerWidth = Math.min(400, width * 0.8);
      const containerHeight = 360; // Increased height to accommodate Progress label and rank progress bar
      const containerX = width / 2 - containerWidth / 2;
      const containerY = height / 2 - containerHeight / 2;
      
      // Background panel
      this.ctx.fillStyle = 'rgba(40, 40, 40, 0.8)';
      this.roundRect(containerX, containerY, containerWidth, containerHeight, 15, true);
      
      // Border
      this.ctx.strokeStyle = '#FF5500';
      this.ctx.lineWidth = 3;
      this.roundRect(containerX, containerY, containerWidth, containerHeight, 15, false, true);
      
      // Title
      this.ctx.fillStyle = '#FF5500';
      this.ctx.textAlign = 'center';
      this.ctx.font = width < 400 ? '26px Arial' : '34px Arial';
      this.ctx.fillText('WORLD COMPLETE!', width / 2, containerY + 50);
      
      // Stats with improved visual hierarchy
      const textX = width / 2;
      const fontSize = width < 400 ? 16 : 18;
      this.ctx.font = `${fontSize}px Arial`;
      
      // Stats labels in dark color
      this.ctx.fillStyle = '#FF5500';
      this.ctx.fillText('Survival Time:', textX, containerY + 100);
      this.ctx.fillText('XP Gained:', textX, containerY + 140);
      this.ctx.fillText('Phoenix Gems Earned:', textX, containerY + 180);
      this.ctx.fillText('Progress:', textX, containerY + 220);
      
      // Stats values in brighter color
      this.ctx.fillStyle = 'rgba(255, 200, 100, 0.9)';
      this.ctx.fillText(`${minutes}:${seconds.toString().padStart(2, '0')}`, textX, containerY + 120);
      this.ctx.fillText(`${this.gameState.xp}`, textX, containerY + 160);
      this.ctx.fillText('5', textX, containerY + 200);
      
      // Add progress percentage value for consistency
      const totalLevelTime = this.gameState.getTotalLevelTime();
      const progressPercent = Math.min(100, (this.gameState.survivalTime / totalLevelTime) * 100);
      this.ctx.fillText(`${progressPercent.toFixed(1)}%`, textX, containerY + 240);
      
      // Draw rank progress if rank system is available
      if (rankSystem) {
        this.drawRankProgress(textX, containerY + 260, containerWidth * 0.8, 20, rankInfo);
      }
      
      // Calculate button pulse effect (grows and shrinks)
      this.buttonPulseTime = (this.buttonPulseTime || 0) + 0.05;
      const pulseFactor = 1 + Math.sin(this.buttonPulseTime) * 0.08; // Pulse between 0.92 and 1.08 size
      
      // Calculate button pulse effect for the menu button (slightly offset)
      const menuButtonPulseTime = this.buttonPulseTime - 0.3; // Offset timing for visual interest
      const menuPulseFactor = 1 + Math.sin(menuButtonPulseTime) * 0.06; // Slightly less pulse than restart
      
      // Apply fade-in to buttons as well
      const buttonOpacity = Math.min(1, (timeSinceComplete - 400) / 600); // Start button fade slightly later
      
      // Continue button (black with orange text)
      const buttonWidth = Math.min(220, containerWidth * 0.8);
      const buttonHeight = 40;
      const buttonX = width / 2 - (buttonWidth * pulseFactor) / 2;
      const buttonY = containerY + containerHeight - 90 - ((pulseFactor - 1) * buttonHeight) / 2; // Adjusted Y position for proper spacing
      
      // Button background with fade-in and pulse
      this.ctx.fillStyle = `rgba(0, 0, 0, ${buttonOpacity})`;
      this.roundRect(buttonX, buttonY, buttonWidth * pulseFactor, buttonHeight * pulseFactor, 20, true);
      
      // Button border with glow effect
      const glowWidth = 2 + Math.sin(this.buttonPulseTime * 2) * 1;
      this.ctx.strokeStyle = `rgba(255, 85, 0, ${buttonOpacity})`;
      this.ctx.lineWidth = glowWidth;
      this.roundRect(buttonX, buttonY, buttonWidth * pulseFactor, buttonHeight * pulseFactor, 20, false, true);
      
      // Button text with fade-in
      this.ctx.fillStyle = `rgba(255, 85, 0, ${buttonOpacity})`;
      this.ctx.font = '18px Arial';
      this.ctx.fillText('CONTINUE', width / 2, buttonY + 25 * pulseFactor);
      
      // Exit to Menu button (smaller, positioned below continue button)
      const menuButtonWidth = Math.min(180, containerWidth * 0.6);
      const menuButtonHeight = 35;
      const menuButtonX = width / 2 - (menuButtonWidth * menuPulseFactor) / 2;
      const menuButtonY = buttonY + buttonHeight * pulseFactor + 20; // Position below continue button with slightly more spacing
      
      // Menu button background with fade-in and pulse
      this.ctx.fillStyle = `rgba(40, 40, 40, ${buttonOpacity})`;
      this.roundRect(menuButtonX, menuButtonY, menuButtonWidth * menuPulseFactor, menuButtonHeight * menuPulseFactor, 15, true);
      
      // Menu button border with glow effect
      const menuGlowWidth = 1.5 + Math.sin(menuButtonPulseTime * 2) * 0.8;
      this.ctx.strokeStyle = `rgba(255, 200, 100, ${buttonOpacity})`;
      this.ctx.lineWidth = menuGlowWidth;
      this.roundRect(menuButtonX, menuButtonY, menuButtonWidth * menuPulseFactor, menuButtonHeight * menuPulseFactor, 15, false, true);
      
      // Menu button text with fade-in
      this.ctx.fillStyle = `rgba(255, 200, 100, ${buttonOpacity})`;
      this.ctx.font = '16px Arial';
      this.ctx.fillText('EXIT TO MENU', width / 2, menuButtonY + 23 * menuPulseFactor);
      
      // Removed tap instruction text
    }
    // Game Over and World Complete screens are already handled earlier in this method
    // No duplicate code needed
  }
  
  /* ===== HELPER METHODS SECTION ===== */
  
  /**
   * Creates a rounded rectangle path
   * @param {number} x - X position
   * @param {number} y - Y position
   * @param {number} width - Width of rectangle
   * @param {number} height - Height of rectangle
   * @param {number} radius - Corner radius
   * @param {boolean} fill - Whether to fill the rectangle
   * @param {boolean} stroke - Whether to stroke the rectangle
   */
  roundRect(x, y, width, height, radius, fill, stroke) {
    this.ctx.beginPath();
    this.ctx.moveTo(x + radius, y);
    this.ctx.lineTo(x + width - radius, y);
    this.ctx.quadraticCurveTo(x + width, y, x + width, y + radius);
    this.ctx.lineTo(x + width, y + height - radius);
    this.ctx.quadraticCurveTo(x + width, y + height, x + width - radius, y + height);
    this.ctx.lineTo(x + radius, y + height);
    this.ctx.quadraticCurveTo(x, y + height, x, y + height - radius);
    this.ctx.lineTo(x, y + radius);
    this.ctx.quadraticCurveTo(x, y, x + radius, y);
    this.ctx.closePath();
    if (fill) {
      this.ctx.fill();
    }
    if (stroke) {
      this.ctx.stroke();
    }
  }
  
  /**
   * Renders health bar with color gradients based on health percentage
   * @param {number} x - X position
   * @param {number} y - Y position
   * @param {number} width - Width of health bar
   * @param {number} height - Height of health bar
   * @param {number} healthPercent - Current health percentage (0-1)
   */
  drawHealthBar(x, y, width, height, healthPercent) {
    // Background
    this.ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
    this.ctx.fillRect(x, y, width, height);
    
    // Calculate health width
    const healthWidth = Math.max(0, width * healthPercent);
    
    // Create gradient based on health
    let gradient;
    if (healthPercent > 0.6) {
      // Green to yellow for high health
      gradient = this.ctx.createLinearGradient(x, 0, x + healthWidth, 0);
      gradient.addColorStop(0, 'rgba(50, 255, 50, 0.8)');
      gradient.addColorStop(1, 'rgba(200, 255, 50, 0.8)');
    } else if (healthPercent > 0.3) {
      // Yellow to orange for medium health
      gradient = this.ctx.createLinearGradient(x, 0, x + healthWidth, 0);
      gradient.addColorStop(0, 'rgba(255, 220, 50, 0.8)');
      gradient.addColorStop(1, 'rgba(255, 150, 50, 0.8)');
    } else {
      // Red for low health with pulsing effect
      const pulseIntensity = 0.7 + 0.3 * Math.sin(Date.now() / 200);
      gradient = this.ctx.createLinearGradient(x, 0, x + healthWidth, 0);
      gradient.addColorStop(0, `rgba(255, 50, 50, ${pulseIntensity})`);
      gradient.addColorStop(1, `rgba(255, 100, 50, ${pulseIntensity})`);
    }
    
    // Fill health bar
    this.ctx.fillStyle = gradient;
    this.ctx.fillRect(x, y, healthWidth, height);
    
    // Draw border
    this.ctx.strokeStyle = 'black';
    this.ctx.lineWidth = 1;
    this.ctx.strokeRect(x, y, width, height);
    
    // Add health label
    this.ctx.fillStyle = 'white';
    this.ctx.font = '12px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.fillText('HEALTH', x + width / 2, y + height - 3);
  }
  
  /**
   * Renders rank progress bar with player's current rank information
   * @param {number} x - X position (center of bar)
   * @param {number} y - Y position
   * @param {number} width - Width of progress bar
   * @param {number} height - Height of progress bar
   * @param {Object} rankInfo - Contains rank data (currentRank, progress, currentXP, neededXP)
   */
  drawRankProgress(x, y, width, height, rankInfo) {
    if (!rankInfo) return;
    
    // Center the bar
    const barX = x - width / 2;
    
    // Title
    this.ctx.fillStyle = '#FF5500';
    this.ctx.font = '16px Arial';
    this.ctx.textAlign = 'center';
    this.ctx.fillText(`Global Rank: ${rankInfo.currentRank}`, x, y - 10);
    
    // Background
    this.ctx.fillStyle = 'rgba(40, 40, 40, 0.7)';
    this.roundRect(barX, y, width, height, 5, true);
    
    // Progress
    const progressWidth = Math.max(0, width * rankInfo.progress);
    
    // Create gradient for progress
    const gradient = this.ctx.createLinearGradient(barX, 0, barX + progressWidth, 0);
    gradient.addColorStop(0, 'rgba(255, 50, 0, 0.8)');
    gradient.addColorStop(1, 'rgba(255, 150, 0, 0.8)');
    
    this.ctx.fillStyle = gradient;
    this.roundRect(barX, y, progressWidth, height, 5, true);
    
    // Border
    this.ctx.strokeStyle = 'rgba(255, 150, 0, 0.5)';
    this.ctx.lineWidth = 1;
    this.roundRect(barX, y, width, height, 5, false, true);
    
    // XP stats
    this.ctx.fillStyle = 'white';
    this.ctx.font = '12px Arial';
    this.ctx.textAlign = 'center';
    
    // Check if max rank
    if (rankInfo.currentRank >= 100) {
      this.ctx.fillText(`Max Rank Achieved!`, x, y + height / 2 + 4);
    } else {
      // Show XP with formatted thousands separator for larger numbers
      const formattedCurrentXP = rankInfo.currentXP.toLocaleString();
      const formattedNeededXP = rankInfo.neededXP.toLocaleString();
      this.ctx.fillText(`${formattedCurrentXP}/${formattedNeededXP} XP (${Math.round(rankInfo.progress * 100)}%)`, x, y + height / 2 + 4);
    }
  }
  
  /**
   * Updates the rank display when XP is gained during gameplay
   * This ensures players see their rank progress in real-time
   */
  updateRankDisplayOnXPGain() {
    const rankSystem = window.rankSystem;
    if (!rankSystem) return;
    
    // Don't update rank display during active gameplay (when rank bar is hidden)
    const isGameActive = this.phoenix && 
                        this.phoenix.health > 0 && 
                        !this.gameState.gameOver && 
                        !this.gameState.worldComplete &&
                        window.gameInstance && 
                        window.gameInstance.isRunning;
                        
    if (isGameActive) {
      // Calculate XP bonus based on current game state
      // This mirrors the XP calculation in game.js for consistency
      const xpGained = Math.round(this.gameState.xp * 0.1); // Only a fraction of in-game XP is added during gameplay
      if (xpGained > 0) {
        // Add XP to rank system but disable notifications
        const showNotification = false; // Never show notifications during gameplay
        rankSystem.addXP(xpGained, showNotification);
        
        // Store latest rankInfo for future UI updates
        this.currentRankInfo = {
          currentRank: rankSystem.getCurrentRank(),
          progress: rankSystem.getRankProgress(),
          currentXP: rankSystem.currentXP,
          neededXP: rankSystem.getXPForNextRank()
        };
      }
    }
  }
}