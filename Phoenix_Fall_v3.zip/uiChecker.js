/**
 * UIChecker - Utility to ensure all UI elements are properly displayed
 * 
 * This class performs checks on critical UI elements to ensure they're properly
 * visible after device sleep/wake, browser tab switches, and other interruptions.
 */
export class UIChecker {
  constructor(game) {
    this.game = game;
    this.checkInterval = null;
    this.lastCheckTime = 0;
    this.checkFrequency = 2000; // Check every 2 seconds
    
    // Bind event handlers to this instance
    this.visibilityChangeHandler = this.handleVisibilityChange.bind(this);
    this.windowFocusHandler = this.handleWindowFocus.bind(this);
    this.windowResizeHandler = this.handleWindowResize.bind(this);
    
    // Set up visibility and focus change event listeners
    document.addEventListener('visibilitychange', this.visibilityChangeHandler);
    window.addEventListener('focus', this.windowFocusHandler);
    window.addEventListener('resize', this.windowResizeHandler);
    
    // Start regular UI checks
    this.startPeriodicChecks();
  }
  
  /**
   * Starts periodic UI element checks
   */
  startPeriodicChecks() {
    // Clear any existing interval
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }
    
    // Set up new check interval
    this.checkInterval = setInterval(() => {
      this.checkUIConsistency();
    }, this.checkFrequency);
    
    // Do an immediate check
    this.checkUIConsistency();
  }
  
  /**
   * Handles document visibility changes (tab switching, app minimizing)
   */
  handleVisibilityChange() {
    if (!document.hidden) {
      // Document is visible again - do a full UI check
      this.checkUIConsistency(true); // true = force thorough check
      this.ensureMenuButtonsClickable(); // Make sure buttons are clickable
    }
  }
  
  /**
   * Handles window focus events
   */
  handleWindowFocus() {
    // When window gains focus, check UI
    this.checkUIConsistency(true); // true = force thorough check
    this.ensureMenuButtonsClickable(); // Make sure buttons are clickable
  }
  
  /**
   * Handles window resize events
   */
  handleWindowResize() {
    // Check UI after resize (with slight delay to let resize complete)
    setTimeout(() => {
      // Check if this is an orientation change
      const isOrientationChange = 
        (window.innerWidth > window.innerHeight && window.lastWidth < window.lastHeight) ||
        (window.innerWidth < window.innerHeight && window.lastWidth > window.lastHeight);
      
      // Store current dimensions for next comparison
      window.lastWidth = window.innerWidth;
      window.lastHeight = window.innerHeight;
      
      // Always do the consistency check
      this.checkUIConsistency(true);
      
      // Ensure main menu buttons are clickable whenever they're visible
      this.ensureMenuButtonsClickable();
      
      // If this appears to be an orientation change and we don't have a dedicated handler
      if (isOrientationChange && !window.orientationHandler) {
        console.log('Orientation change detected by UIChecker');
        
        // Adjust the UI manually since we don't have the orientation handler
        this.handleOrientationChange();
      }
    }, 100);
  }
  
  /**
   * Handle orientation changes when OrientationHandler isn't available
   * This is a fallback method for browsers that don't support orientation events
   */
  handleOrientationChange() {
    const orientation = window.innerWidth > window.innerHeight ? 'landscape' : 'portrait';
    console.log(`UIChecker detected orientation: ${orientation}`);
    
    // Apply basic adjustments for orientation
    const rankBar = document.querySelector('.rank-bar-container');
    if (rankBar) {
      if (orientation === 'portrait') {
        rankBar.style.width = '85%';
        rankBar.style.maxWidth = '400px';
      } else {
        rankBar.style.width = '60%';
        rankBar.style.maxWidth = '500px';
      }
    }
    
    // Also check settings button position
    const settingsButton = document.querySelector('.settings-button');
    if (settingsButton) {
      if (orientation === 'portrait') {
        settingsButton.style.top = '110px';
      } else {
        settingsButton.style.top = '120px';
      }
    }
    
    // Check for pause menu
    if (this.game && this.game.pauseMenu && this.game.pauseMenu.menuElement) {
      const menuPanel = this.game.pauseMenu.menuElement.querySelector('.pause-menu-panel');
      if (menuPanel) {
        if (orientation === 'portrait') {
          menuPanel.style.width = '90%';
          menuPanel.style.maxWidth = '320px';
        } else {
          menuPanel.style.width = '80%';
          menuPanel.style.maxWidth = '350px';
        }
      }
    }
  }
  
  /**
   * Check and fix UI consistency issues
   * @param {boolean} forceThorough - Whether to do a thorough check regardless of time
   */
  checkUIConsistency(forceThorough = false) {
    const now = Date.now();
    const timeSinceLastCheck = now - this.lastCheckTime;
    
    // Only do thorough checks periodically unless forced
    const doThoroughCheck = forceThorough || timeSinceLastCheck > 5000;
    
    // Always check critical elements
    this.ensureMainMenuConsistency();
    
    // Always ensure buttons are clickable, regardless of thorough check
    this.ensureMenuButtonsClickable();
    
    // Do a more thorough check if needed
    if (doThoroughCheck) {
      this.ensureAllUIElementsConsistency();
      this.ensureButtonPositioning(); // Always check button positioning
      this.lastCheckTime = now;
    }
  }
  
  /**
   * Ensures button positioning is consistent
   */
  ensureButtonPositioning() {
    // Check if pause button and settings button exist
    const pauseButton = this.game && this.game.pauseButton && this.game.pauseButton.element;
    const settingsButton = document.querySelector('.settings-button');
    
    // Reposition pause button below game data (around 100px from top)
    if (pauseButton) {
      pauseButton.style.top = '100px';
    }
    
    if (pauseButton && settingsButton) {
      // Make sure settings button is below rank bar
      const rankBar = document.querySelector('.rank-bar-container');
      const settingsTop = window.innerWidth < 768 ? '110px' : '120px';
      
      // If rank bar exists, position settings button below it
      if (rankBar) {
        const rankRect = rankBar.getBoundingClientRect();
        const newTop = rankRect.bottom + 10 + 'px';
        settingsButton.style.top = newTop;
      } else {
        // Fallback position if no rank bar
        settingsButton.style.top = settingsTop;
      }
    }
  }
  /**
   * Ensures the main menu is in a consistent state
   */
  ensureMainMenuConsistency() {
    if (!window.mainMenu) return;
    
    // First check if we're in the right state
    const isRunning = this.game && this.game.isRunning;
    const isPaused = this.game && this.game.pauseMenu && this.game.pauseMenu.isPaused;
    const isGameOver = this.game && this.game.gameState && this.game.gameState.gameOver;
    const isWorldComplete = this.game && this.game.gameState && this.game.gameState.worldComplete;
    
    // Determine correct menu visibility state
    const shouldMenuBeVisible = !isRunning && !isPaused;
    
    // Check if the menu container exists and has correct visibility
    const menuContainer = window.mainMenu.elements.menuContainer;
    if (menuContainer) {
      const isMenuVisible = menuContainer.style.display !== 'none' && 
                           parseFloat(getComputedStyle(menuContainer).opacity) > 0.1;
      
      // Fix inconsistent menu visibility
      if (shouldMenuBeVisible && !isMenuVisible) {
        console.log('UIChecker: Main menu should be visible but isn\'t - fixing');
        // Use the correct show method based on game state
        if (isGameOver || isWorldComplete) {
          window.mainMenu.showWithoutRankAndSettings();
        } else {
          window.mainMenu.show();
        }
      } else if (!shouldMenuBeVisible && isMenuVisible) {
        console.log('UIChecker: Main menu should be hidden but isn\'t - fixing');
        window.mainMenu.hide();
      }
    }
    
    // Always ensure start button consistency when menu should be visible
    if (shouldMenuBeVisible) {
      this.ensureStartButtonConsistency();
    }
  }
  
  /**
   * Ensures the start button is in a consistent state
   */
  ensureStartButtonConsistency() {
    if (!window.mainMenu) return;
    
    const startButton = window.mainMenu.elements.startButton;
    if (!startButton) {
      console.log('UIChecker: Start button missing - recreating');
      window.mainMenu.recreateStartButton();
      return;
    }
    
    // Check that the start button is visible when it should be
    const menuContainer = window.mainMenu.elements.menuContainer;
    if (menuContainer && menuContainer.style.display !== 'none') {
      const isButtonVisible = startButton.style.display !== 'none' && 
                             parseFloat(getComputedStyle(startButton).opacity) > 0.1;
      
      if (!isButtonVisible) {
        console.log('UIChecker: Start button should be visible but isn\'t - fixing');
        window.mainMenu.showStartButton();
      }
    }
  }
  
  /**
   * Performs a thorough check of all UI elements
   */
  ensureAllUIElementsConsistency() {
    // Check if game is over or world is complete
    const isGameOver = this.game && this.game.gameState && this.game.gameState.gameOver;
    const isWorldComplete = this.game && this.game.gameState && this.game.gameState.worldComplete;
    
    // Check rank bar consistency
    const rankBarElement = document.querySelector('.rank-bar-container');
    if (rankBarElement) {
      const isRunning = this.game && this.game.isRunning;
      // Rank bar should NOT be visible when game is over or world is complete
      const shouldRankBarBeVisible = !isRunning && !isGameOver && !isWorldComplete;
      const isRankBarVisible = rankBarElement.style.display !== 'none' && 
                              parseFloat(getComputedStyle(rankBarElement).opacity) > 0.1;
      
      if (shouldRankBarBeVisible && !isRankBarVisible) {
        console.log('UIChecker: Rank bar should be visible but isn\'t - fixing');
        rankBarElement.style.display = 'flex';
        setTimeout(() => {
          rankBarElement.style.opacity = '1';
        }, 10);
      } else if (!shouldRankBarBeVisible && isRankBarVisible) {
        console.log('UIChecker: Rank bar should be hidden but isn\'t - fixing');
        rankBarElement.style.opacity = '0';
        setTimeout(() => {
          rankBarElement.style.display = 'none';
        }, 500);
      }
    }
    
    // Check pause button consistency
    if (this.game && this.game.pauseButton) {
      const isRunning = this.game.isRunning;
      const isPaused = this.game.pauseMenu && this.game.pauseMenu.isPaused;
      const shouldPauseButtonBeVisible = isRunning && !isPaused;
      
      // Also check and update settings button visibility based on game state
      const settingsButton = document.querySelector('.settings-button');
      if (settingsButton) {
        const isSettingsButtonVisible = settingsButton.style.display !== 'none' && 
                                       parseFloat(getComputedStyle(settingsButton).opacity) > 0.1;
        
        // Settings button should only be visible when game is not running
        // AND when game is not over and world is not complete
        if ((isRunning || isGameOver || isWorldComplete) && isSettingsButtonVisible) {
          console.log('UIChecker: Settings button should be hidden during gameplay or after game end - fixing');
          settingsButton.style.opacity = '0';
          settingsButton.style.display = 'none';
        } else if (!isRunning && !isGameOver && !isWorldComplete && !isSettingsButtonVisible) {
          console.log('UIChecker: Settings button should be visible in menu - fixing');
          settingsButton.style.display = 'block';
          setTimeout(() => {
            settingsButton.style.opacity = '1';
          }, 10);
        }
      }
      
      const pauseButton = this.game.pauseButton.element;
      if (pauseButton) {
        const isPauseButtonVisible = pauseButton.style.display !== 'none';
        
        if (shouldPauseButtonBeVisible && !isPauseButtonVisible) {
          console.log('UIChecker: Pause button should be visible but isn\'t - fixing');
          this.game.pauseButton.show();
        } else if (!shouldPauseButtonBeVisible && isPauseButtonVisible) {
          console.log('UIChecker: Pause button should be hidden but isn\'t - fixing');
          this.game.pauseButton.hide();
        }
      }
    }
    
    // Emergency start button functionality has been removed
    // The system now uses the main menu's start button exclusively
    // This simplified approach improves reliability and user experience
    const emergencyButton = document.querySelector('.emergency-start-button');
    if (emergencyButton) {
      if (window.mainMenu && window.mainMenu.elements.startButton) {
        // No need for emergency button if regular button exists
        console.log('UIChecker: Removing redundant emergency button');
        emergencyButton.remove();
      }
    }
  }
  
  /**
   * Ensures that menu buttons are clickable whenever they're visible
   * This addresses the issue where backdrop elements might block button clicks
   */
  ensureMenuButtonsClickable() {
    if (!window.mainMenu) return;
    
    // Get all backdrop and container elements that might block clicks
    const backdropElements = [
      // Main menu elements
      window.mainMenu.elements.menuContainer,
      document.querySelector('.menu-backdrop'),
      document.querySelector('.menu-background'),
      document.querySelector('.menu-overlay'),
      // Settings elements if they exist
      document.querySelector('.settings-panel-backdrop'),
      document.querySelector('.settings-container')
    ];
    
    // For each backdrop element, ensure pointer-events is properly set
    backdropElements.forEach(element => {
      if (element) {
        const isVisible = element.style.display !== 'none' && 
                        parseFloat(getComputedStyle(element).opacity) > 0.1;
        
        if (isVisible) {
          // Get all child elements that represent buttons
          const buttons = element.querySelectorAll('button, .button, [role="button"]');
          
          // First, ensure the backdrop doesn't block clicks if buttons are visible
          if (buttons.length > 0) {
            // Only apply pointer-events: none to the backdrop if it's not a button container itself
            if (!element.classList.contains('button') && 
                !element.tagName === 'BUTTON' && 
                element.getAttribute('role') !== 'button') {
              element.style.pointerEvents = 'auto'; // Enable pointer events for container
            }
          }
          
          // Then ensure all buttons inside have pointer-events enabled
          buttons.forEach(button => {
            button.style.pointerEvents = 'auto';
            button.style.zIndex = parseInt(button.style.zIndex || 0) + 10; // Increase z-index
            
            // Log for debugging
            console.log('UIChecker: Ensuring button clickable:', button);
          });
        }
      }
    });
    
    // Explicitly check the start button
    if (window.mainMenu.elements.startButton) {
      window.mainMenu.elements.startButton.style.pointerEvents = 'auto';
      window.mainMenu.elements.startButton.style.zIndex = '300'; // High z-index
    }
  }
  
  /**
   * Cleans up all event listeners when no longer needed
   */
  cleanup() {
    // Clear interval
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
    
    // Remove event listeners
    document.removeEventListener('visibilitychange', this.visibilityChangeHandler);
    window.removeEventListener('focus', this.windowFocusHandler);
    window.removeEventListener('resize', this.windowResizeHandler);
  }
}