/**
 * World 4 Configuration
 * An ethereal celestial realm with cosmic hazards and stellar enemies
 */
export const world4 = {
    name: "Astral Ascension",
    description: "A mystical journey through the cosmic heights of the celestial realm",
    
    // World-specific settings
    settings: {
        backgroundColor: '#0a0a2a', // Deep space blue
        ambientLight: 0.5, // Bright for stellar glow
        difficulty: 4,
        timeToComplete: 210, // Longest world yet
        requiredProgress: 100
    },
    
    // Enemy spawn configuration
    enemies: {
        flameHelicopter: {
            spawnRate: 1400, // Fastest spawn rate yet
            maxActive: 5,
            speed: 3.0,
            health: 160
        },
        magmaBat: {
            spawnRate: 2000,
            maxActive: 4,
            speed: 3.5,
            health: 110
        },
        starweaver: { // New enemy type
            spawnRate: 3000,
            maxActive: 2,
            speed: 2.5,
            health: 300
        },
        cosmicPhoenix: { // New enemy type
            spawnRate: 4500,
            maxActive: 2,
            speed: 4.0,
            health: 200
        }
    },
    
    // Collectible configuration
    collectibles: {
        ember: {
            spawnRate: 700,
            maxActive: 8,
            value: 25
        },
        powerEmber: {
            spawnRate: 3500,
            maxActive: 2,
            value: 100
        },
        stellarEmber: { // New collectible type
            spawnRate: 5000,
            maxActive: 1,
            value: 150
        }
    },
    
    // Level progression
    progression: {
        xpMultiplier: 1.8, // 80% more XP
        levelThresholds: [250, 500, 750] // Highest XP requirements
    }
};