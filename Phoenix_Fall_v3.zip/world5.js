/**
 * World 5 Configuration
 * The ultimate challenge featuring infernal enemies and hellfire hazards
 * This is the final and most difficult world in the game
 */
export const world5 = {
    name: "Infernal Ascent",
    description: "The final trial through the heart of the infernal realm",
    
    // World-specific settings
    settings: {
        backgroundColor: '#1a0505', // Deep crimson
        ambientLight: 0.2, // Dark and ominous
        difficulty: 5, // Maximum difficulty
        timeToComplete: 240, // Longest world
        requiredProgress: 100
    },
    
    // Enemy spawn configuration with the most challenging combinations
    enemies: {
        flameHelicopter: {
            spawnRate: 1200, // Fastest spawn rate of all worlds
            maxActive: 6,
            speed: 3.2,
            health: 180
        },
        magmaBat: {
            spawnRate: 1800,
            maxActive: 4,
            speed: 3.8,
            health: 130
        },
        hellLord: { // New elite enemy type
            spawnRate: 2500,
            maxActive: 2,
            speed: 2.8,
            health: 400
        },
        infernalPhoenix: { // Final boss-type enemy
            spawnRate: 4000,
            maxActive: 1,
            speed: 4.5,
            health: 500
        }
    },
    
    // Collectible configuration with highest risk-reward balance
    collectibles: {
        ember: {
            spawnRate: 600,
            maxActive: 10,
            value: 30
        },
        powerEmber: {
            spawnRate: 3000,
            maxActive: 3,
            value: 125
        },
        infernalEmber: { // New most valuable collectible type
            spawnRate: 4000,
            maxActive: 2,
            value: 200
        }
    },
    
    // World-specific hazards
    hazards: {
        infernalBeam: {
            spawnRate: 2000,      // 2 seconds between spawns
            maxActive: 4,
            damage: 60,           // Highest damage
            width: 80,
            chargeTime: 800,      // 0.8 seconds charge
            beamDuration: 2000,   // 2 seconds of active beam
            cooldown: 400,        // 0.4 seconds cooldown
            pattern: 'cross',     // Beams form crossing patterns
            warning: true,
            spawnLocations: [
                { x: 0.2, weight: 1 },   // 20% from left
                { x: 0.4, weight: 1.5 }, // 40% from left
                { x: 0.6, weight: 1.5 }, // 60% from left
                { x: 0.8, weight: 1 }    // 80% from left
            ]
        },
        hellPortal: {
            spawnRate: 3500,      // 3.5 seconds between spawns
            maxActive: 3,
            damage: 75,           // Extreme damage
            radius: 100,
            chargeTime: 1000,     // 1 second to open
            activeTime: 4000,     // 4 seconds active
            closeTime: 1000,      // 1 second to close
            pullForce: 3.5,       // Strong pull force
            warningTime: 1200     // 1.2 seconds warning
        }
    },
    
    // Game Systems with coordinated hazard patterns
    systems: {
        hazardCoordination: {
            enabled: true,
            patterns: {
                infernalCrossfire: {
                    interval: 7000,   // 7 seconds between pattern activation
                    duration: 5000,   // Pattern lasts 5 seconds
                    beamCount: 4,     // Four beams in cross pattern
                    portalCount: 1    // One portal in the center
                },
                hellstorm: {
                    interval: 15000,  // 15 seconds between pattern activation
                    duration: 8000,   // Pattern lasts 8 seconds
                    beamCount: 2,     // Two tracking beams
                    portalCount: 3    // Three portals in triangle formation
                }
            }
        },
        difficulty: {
            scaling: {
                baseMultiplier: 1.0,
                perLevelIncrease: 0.15,   // 15% increase per level
                maxMultiplier: 2.5        // Cap at 250% difficulty
            },
            modifiers: {
                spawnRate: 0.85,          // Even faster spawns
                damage: 1.2,              // More damage
                warningTime: 0.9,         // Less warning time
                patternFrequency: 1.2     // More frequent patterns
            }
        }
    },
    
    // Level progression with maximum rewards
    progression: {
        xpMultiplier: 2.0, // Double XP
        levelThresholds: [300, 600, 900] // Highest XP requirements
    }
};